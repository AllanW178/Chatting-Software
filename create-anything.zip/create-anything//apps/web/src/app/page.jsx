import Header from "../components/Header";
import Hero from "../components/Hero";
import Features from "../components/Features";
import ProductShowcase from "../components/ProductShowcase";
import Pricing from "../components/Pricing";
import Testimonials from "../components/Testimonials";
import FAQ from "../components/FAQ";
import ContactCTA from "../components/ContactCTA";
import Footer from "../components/Footer";
import FloatingContact from "../components/FloatingContact";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#121212] relative">
      {/* Fixed Header */}
      <Header />

      {/* Hero Section - Animated background with compelling headline */}
      <Hero />

      {/* Features Section - Interactive tabbed interface */}
      <Features />

      {/* Product Showcase - Interactive cards with hover effects */}
      <ProductShowcase />

      {/* Pricing Section - Comparison table with monthly/yearly toggle */}
      <Pricing />

      {/* Testimonials - Social proof with animated carousel */}
      <Testimonials />

      {/* FAQ Section - Expandable accordion interface */}
      <FAQ />

      {/* Contact CTA - Final call to action */}
      <ContactCTA />

      {/* Footer - Newsletter signup and social links */}
      <Footer />

      {/* Floating Contact Widget */}
      <FloatingContact />
    </div>
  );
}

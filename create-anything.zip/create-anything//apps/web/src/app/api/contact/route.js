import sql from "../utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { name, email, company, message } = body;

    // Validate required fields
    if (!name || !email || !message) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return Response.json({ error: "Invalid email format" }, { status: 400 });
    }

    // Save contact submission to database
    const result = await sql`
      INSERT INTO contact_submissions (name, email, company, message)
      VALUES (${name}, ${email}, ${company || null}, ${message})
      RETURNING id, created_at
    `;

    const submission = result[0];

    // Log the submission for monitoring
    console.log("Contact form submission saved:", {
      id: submission.id,
      name,
      email,
      company: company || "Not provided",
      timestamp: submission.created_at,
    });

    // Here you could also:
    // 1. Send notification email to your team
    // 2. Send confirmation email to the user
    // 3. Integrate with your CRM
    // 4. Add to marketing automation

    // Return success response
    return Response.json(
      {
        success: true,
        message:
          "Thank you for your message. We will get back to you within 24 hours!",
        submissionId: submission.id,
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Contact form error:", error);

    return Response.json(
      { error: "Failed to submit your message. Please try again." },
      { status: 500 },
    );
  }
}

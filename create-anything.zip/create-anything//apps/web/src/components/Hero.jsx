"use client";

import { useState, useEffect } from "react";
import { ArrowRight, Play } from "lucide-react";

export default function Hero() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);

    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100,
      });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <section className="min-h-screen bg-white dark:bg-[#121212] relative flex items-center justify-center px-6 pt-20 pb-12 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Floating particles */}
        <div
          className="absolute w-2 h-2 bg-[#F5CDB3] rounded-full opacity-60 animate-bounce"
          style={{
            left: `${20 + mousePosition.x * 0.02}%`,
            top: `${30 + mousePosition.y * 0.01}%`,
            animationDelay: "0s",
            animationDuration: "3s",
          }}
        ></div>
        <div
          className="absolute w-3 h-3 bg-[#E7B18E] rounded-full opacity-40"
          style={{
            right: `${15 + mousePosition.x * 0.03}%`,
            top: `${20 + mousePosition.y * 0.02}%`,
            transform: `translate(${mousePosition.x * 0.1}px, ${mousePosition.y * 0.1}px)`,
            transition: "transform 0.2s ease-out",
          }}
        ></div>
        <div
          className="absolute w-1 h-1 bg-[#D4A574] rounded-full opacity-80 animate-pulse"
          style={{
            left: `${70 + mousePosition.x * 0.02}%`,
            bottom: `${40 + mousePosition.y * 0.01}%`,
            animationDelay: "1s",
          }}
        ></div>

        {/* Gradient Orbs */}
        <div
          className="absolute w-96 h-96 bg-gradient-to-r from-[#F5CDB3]/20 to-[#E7B18E]/20 rounded-full blur-3xl"
          style={{
            left: `${-10 + mousePosition.x * 0.05}%`,
            top: `${-10 + mousePosition.y * 0.03}%`,
            transform: "translate(-50%, -50%)",
            animation: "float 6s ease-in-out infinite",
          }}
        ></div>
        <div
          className="absolute w-80 h-80 bg-gradient-to-l from-[#D0ECEE]/30 to-[#B8E5E8]/20 rounded-full blur-2xl"
          style={{
            right: `${-5 + mousePosition.x * 0.03}%`,
            bottom: `${-5 + mousePosition.y * 0.04}%`,
            transform: "translate(50%, 50%)",
            animation: "float 8s ease-in-out infinite reverse",
          }}
        ></div>
      </div>

      <div className="max-w-6xl mx-auto text-center relative z-10">
        {/* Animated Badge */}
        <div
          className={`
          mb-8 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#F5CDB3]/20 border border-[#F5CDB3]/50 rounded-full px-6 py-3 backdrop-blur-sm">
            <div className="w-2 h-2 bg-[#E7B18E] rounded-full animate-pulse"></div>
            <span
              className="text-[#8B6914] dark:text-[#F5CDB3] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Transform Your Business
            </span>
          </div>
        </div>

        {/* Main Headlines */}
        <div
          className={`
          mb-8 transition-all duration-1000 ease-out delay-200
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <h1
            className="text-[clamp(3rem,8vw,6rem)] leading-[0.95] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            <span className="block">Sell Smarter,</span>
            <span className="block">
              Grow{" "}
              <span className="relative inline-block">
                <span className="relative z-10">Faster</span>
                {/* Animated underline */}
                <div className="absolute bottom-2 left-0 w-full h-4 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] opacity-80 -skew-x-12 animate-pulse"></div>
              </span>
            </span>
          </h1>
        </div>

        {/* Sub-description */}
        <div
          className={`
          mb-12 transition-all duration-1000 ease-out delay-400
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          <p
            className="text-[clamp(1.1rem,2.5vw,1.4rem)] font-normal text-gray-600 dark:text-gray-300 leading-relaxed max-w-3xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            The complete platform to{" "}
            <span className="font-semibold text-black dark:text-white">
              launch
            </span>
            ,{" "}
            <span className="font-semibold text-black dark:text-white">
              manage
            </span>
            , and{" "}
            <span className="font-semibold text-black dark:text-white">
              scale
            </span>{" "}
            your business.
            <br className="hidden md:block" />
            Join thousands of successful entrepreneurs who trust our solution.
          </p>
        </div>

        {/* CTA Buttons */}
        <div
          className={`
          flex flex-col sm:flex-row items-center justify-center gap-6 mb-12 transition-all duration-1000 ease-out delay-600
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}
        `}
        >
          {/* Primary CTA */}
          <button className="group bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-semibold text-lg px-10 py-4 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-xl flex items-center gap-3">
            <span>Start Free Trial</span>
            <ArrowRight
              size={20}
              className="group-hover:translate-x-1 transition-transform duration-200"
            />
          </button>

          {/* Secondary CTA */}
          <button className="group flex items-center gap-3 text-black dark:text-white font-medium text-lg hover:text-[#F5CDB3] transition-colors duration-200">
            <div className="w-12 h-12 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center group-hover:bg-[#F5CDB3]/20 transition-all duration-200 group-hover:scale-110">
              <Play size={16} className="ml-0.5" />
            </div>
            <span>Watch Demo</span>
          </button>
        </div>

        {/* Trust Badges */}
        <div
          className={`
          flex flex-wrap items-center justify-center gap-8 opacity-60 transition-all duration-1000 ease-out delay-800
          ${isVisible ? "opacity-60 translate-y-0" : "opacity-0 translate-y-4"}
        `}
        >
          <div
            className="text-sm text-gray-500 dark:text-gray-400 font-medium"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Trusted by 50K+ businesses
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">•</div>
          <div
            className="text-sm text-gray-500 dark:text-gray-400 font-medium"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            No credit card required
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">•</div>
          <div
            className="text-sm text-gray-500 dark:text-gray-400 font-medium"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            14-day free trial
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-gray-400 dark:border-gray-600 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-gray-400 dark:bg-gray-600 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes float {
          0%, 100% { 
            transform: translate(-50%, -50%) translateY(0px) rotate(0deg);
          }
          50% { 
            transform: translate(-50%, -50%) translateY(-20px) rotate(2deg);
          }
        }
      `}</style>
    </section>
  );
}

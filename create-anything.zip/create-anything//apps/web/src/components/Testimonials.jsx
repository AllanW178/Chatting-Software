"use client";

import { useState, useEffect, useRef } from "react";
import { ArrowLeft, ArrowRight, Star, Quote, Users } from "lucide-react";

export default function Testimonials() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "CEO, TechStart Inc.",
      company: "TechStart",
      rating: 5,
      content:
        "This platform completely transformed how we manage our business. The analytics dashboard gives us insights we never had before, and the automation features saved us countless hours. Our revenue increased by 150% in just 6 months.",
      avatar:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face&auto=format&q=80",
      stats: { growth: "150%", time: "6 months" },
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Founder, Design Studio",
      company: "Chen Design",
      rating: 5,
      content:
        "The user experience is incredible. Everything just works seamlessly together. Our team productivity improved dramatically, and our clients love the professional touch it adds to our deliverables. Best investment we've made.",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face&auto=format&q=80",
      stats: { growth: "200%", time: "3 months" },
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      role: "Marketing Director",
      company: "GrowthCo",
      rating: 5,
      content:
        "We tried several solutions before finding this one. The difference is night and day. The customer support is outstanding, and the platform scales beautifully as we grow. Highly recommend to any serious business.",
      avatar:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face&auto=format&q=80",
      stats: { growth: "300%", time: "8 months" },
    },
    {
      id: 4,
      name: "David Thompson",
      role: "Operations Manager",
      company: "LogiFlow",
      rating: 5,
      content:
        "The automation capabilities are game-changing. What used to take our team days now happens automatically in hours. The ROI has been incredible - we've reduced costs while improving quality across all operations.",
      avatar:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face&auto=format&q=80",
      stats: { growth: "180%", time: "4 months" },
    },
    {
      id: 5,
      name: "Lisa Wang",
      role: "Product Manager",
      company: "InnovateLab",
      rating: 5,
      content:
        "This solution helped us scale from a small startup to a growing company. The insights we get from the analytics are invaluable for making strategic decisions. Our team efficiency has never been higher.",
      avatar:
        "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&h=400&fit=crop&crop=face&auto=format&q=80",
      stats: { growth: "250%", time: "5 months" },
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Auto-advance carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentSlide(
      (prev) => (prev - 1 + testimonials.length) % testimonials.length,
    );
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  const currentTestimonial = testimonials[currentSlide];

  return (
    <section
      id="testimonials"
      ref={sectionRef}
      className="py-20 md:py-24 lg:py-32 px-6 bg-white dark:bg-[#121212] relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-40 left-20 w-32 h-32 bg-[#D0ECEE]/10 rounded-full blur-2xl"></div>
        <div className="absolute bottom-40 right-20 w-48 h-48 bg-[#F5CDB3]/10 rounded-full blur-3xl"></div>

        {/* Floating quotes */}
        <div className="absolute top-20 left-10 text-[#F5CDB3]/20 transform rotate-12">
          <Quote size={48} />
        </div>
        <div className="absolute bottom-20 right-10 text-[#D0ECEE]/20 transform -rotate-12">
          <Quote size={64} />
        </div>
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Section Header */}
        <div
          className={`
          text-center mb-16 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#D0ECEE]/20 border border-[#D0ECEE]/30 rounded-full px-4 py-2 mb-6">
            <Users size={16} className="text-[#2A5A58] dark:text-[#B8E5E8]" />
            <span
              className="text-[#2A5A58] dark:text-[#B8E5E8] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Testimonials
            </span>
          </div>

          <h2
            className="text-[clamp(2.25rem,6vw,4rem)] leading-[1.1] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            Loved by businesses
            <br />
            <span className="relative inline-block">
              <span className="relative z-10">worldwide</span>
              <div className="absolute bottom-2 left-0 w-full h-3 bg-gradient-to-r from-[#D0ECEE] to-[#B8E5E8] opacity-60 -skew-x-6"></div>
            </span>
          </h2>

          <p
            className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Join thousands of satisfied customers who have transformed their
            businesses with our platform.
          </p>
        </div>

        {/* Main Testimonial Display */}
        <div
          className={`
          grid lg:grid-cols-2 gap-16 items-center mb-16 transition-all duration-1000 ease-out delay-300
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          {/* Left - Avatar and Company Info */}
          <div className="relative">
            {/* Background Decoration */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#F5CDB3]/20 to-[#E7B18E]/20 rounded-3xl blur-3xl transform -rotate-6"></div>

            <div className="relative bg-white dark:bg-[#1A1A1A] rounded-3xl p-8 shadow-2xl">
              {/* Quote Icon */}
              <div className="absolute -top-4 left-8">
                <div className="w-12 h-12 bg-[#F5CDB3] rounded-2xl flex items-center justify-center shadow-lg">
                  <Quote size={24} className="text-black" />
                </div>
              </div>

              <div className="text-center pt-8">
                {/* Avatar */}
                <div className="relative mb-6">
                  <div className="w-32 h-32 mx-auto rounded-2xl overflow-hidden shadow-xl">
                    <img
                      src={currentTestimonial.avatar}
                      alt={currentTestimonial.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Floating Stats */}
                  <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs font-bold px-3 py-2 rounded-lg shadow-lg">
                    +{currentTestimonial.stats.growth}
                  </div>
                  <div className="absolute -bottom-2 -left-2 bg-blue-500 text-white text-xs font-bold px-3 py-2 rounded-lg shadow-lg">
                    {currentTestimonial.stats.time}
                  </div>
                </div>

                {/* Name and Role */}
                <h3
                  className="text-2xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  {currentTestimonial.name}
                </h3>

                <p
                  className="text-gray-600 dark:text-gray-400 mb-4"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  {currentTestimonial.role}
                </p>

                {/* Company Badge */}
                <div className="inline-flex items-center gap-2 bg-[#D0ECEE]/20 rounded-full px-4 py-2">
                  <div className="w-2 h-2 bg-[#2A5A58] rounded-full"></div>
                  <span className="text-[#2A5A58] dark:text-[#B8E5E8] font-medium text-sm">
                    {currentTestimonial.company}
                  </span>
                </div>

                {/* Rating Stars */}
                <div className="flex justify-center gap-1 mt-4">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star
                      key={i}
                      size={20}
                      className="text-yellow-400 fill-current"
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right - Testimonial Content */}
          <div className="space-y-8">
            {/* Testimonial Text */}
            <blockquote
              className="text-xl md:text-2xl leading-relaxed text-gray-800 dark:text-gray-200 font-medium"
              style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
            >
              "{currentTestimonial.content}"
            </blockquote>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              {/* Dots */}
              <div className="flex items-center gap-3">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => goToSlide(index)}
                    className={`
                      w-3 h-3 rounded-full transition-all duration-300
                      ${
                        index === currentSlide
                          ? "bg-[#F5CDB3] scale-125"
                          : "bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500"
                      }
                    `}
                    aria-label={`Go to testimonial ${index + 1}`}
                  />
                ))}
              </div>

              {/* Arrow Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={prevSlide}
                  className="w-12 h-12 rounded-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-gray-700 flex items-center justify-center hover:bg-[#F5CDB3] hover:border-[#F5CDB3] transition-all duration-200 hover:scale-110 shadow-lg"
                  aria-label="Previous testimonial"
                >
                  <ArrowLeft
                    size={20}
                    className="text-gray-600 dark:text-gray-400"
                  />
                </button>

                <button
                  onClick={nextSlide}
                  className="w-12 h-12 rounded-full bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-gray-700 flex items-center justify-center hover:bg-[#F5CDB3] hover:border-[#F5CDB3] transition-all duration-200 hover:scale-110 shadow-lg"
                  aria-label="Next testimonial"
                >
                  <ArrowRight
                    size={20}
                    className="text-gray-600 dark:text-gray-400"
                  />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* All Testimonials Preview */}
        <div
          className={`
          transition-all duration-1000 ease-out delay-600
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-4 mb-12">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.id}
                onClick={() => goToSlide(index)}
                className={`
                  group relative p-4 rounded-2xl border-2 transition-all duration-300 hover:scale-105
                  ${
                    index === currentSlide
                      ? "border-[#F5CDB3] bg-[#F5CDB3]/10"
                      : "border-gray-200 dark:border-gray-700 hover:border-[#F5CDB3]/50"
                  }
                `}
              >
                <div className="text-center">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-xl mx-auto mb-3 object-cover"
                  />
                  <h4
                    className="font-semibold text-sm text-black dark:text-white mb-1"
                    style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                  >
                    {testimonial.name}
                  </h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {testimonial.company}
                  </p>

                  {/* Growth Badge */}
                  <div className="mt-2 text-xs bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 px-2 py-1 rounded-full">
                    +{testimonial.stats.growth}
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Stats Bar */}
          <div className="bg-gradient-to-r from-[#F5CDB3]/10 to-[#D0ECEE]/10 rounded-2xl p-8">
            <div className="grid md:grid-cols-4 gap-8 text-center">
              <div>
                <div
                  className="text-3xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  50,000+
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  Happy Customers
                </div>
              </div>

              <div>
                <div
                  className="text-3xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  98%
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  Customer Satisfaction
                </div>
              </div>

              <div>
                <div
                  className="text-3xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  200%
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  Average Growth
                </div>
              </div>

              <div>
                <div
                  className="text-3xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  24/7
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  Support Available
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

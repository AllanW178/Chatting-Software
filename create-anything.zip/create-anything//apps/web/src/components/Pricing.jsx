"use client";

import { useState, useRef, useEffect } from "react";
import { Check, X, Star, Zap, Crown, Rocket } from "lucide-react";

export default function Pricing() {
  const [isYearly, setIsYearly] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const plans = [
    {
      name: "Starter",
      description: "Perfect for individuals and small projects",
      icon: Zap,
      monthlyPrice: 19,
      yearlyPrice: 15,
      color: "from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700",
      textColor: "text-gray-900 dark:text-white",
      buttonStyle:
        "bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200",
      features: [
        { name: "Up to 3 websites", included: true },
        { name: "10GB storage", included: true },
        { name: "Basic analytics", included: true },
        { name: "Email support", included: true },
        { name: "Custom domain", included: false },
        { name: "Advanced analytics", included: false },
        { name: "Priority support", included: false },
        { name: "White-label solution", included: false },
      ],
    },
    {
      name: "Professional",
      description: "Best for growing businesses and teams",
      icon: Star,
      monthlyPrice: 49,
      yearlyPrice: 39,
      popular: true,
      color: "from-[#F5CDB3] to-[#E7B18E]",
      textColor: "text-black",
      buttonStyle: "bg-black text-white hover:bg-gray-800",
      features: [
        { name: "Up to 10 websites", included: true },
        { name: "100GB storage", included: true },
        { name: "Advanced analytics", included: true },
        { name: "Priority support", included: true },
        { name: "Custom domain", included: true },
        { name: "A/B testing", included: true },
        { name: "API access", included: false },
        { name: "White-label solution", included: false },
      ],
    },
    {
      name: "Enterprise",
      description: "For large organizations with custom needs",
      icon: Crown,
      monthlyPrice: 99,
      yearlyPrice: 79,
      color: "from-[#D0ECEE] to-[#B8E5E8]",
      textColor: "text-black",
      buttonStyle: "bg-black text-white hover:bg-gray-800",
      features: [
        { name: "Unlimited websites", included: true },
        { name: "500GB storage", included: true },
        { name: "Advanced analytics", included: true },
        { name: "24/7 phone support", included: true },
        { name: "Custom domain", included: true },
        { name: "A/B testing", included: true },
        { name: "Full API access", included: true },
        { name: "White-label solution", included: true },
      ],
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="pricing"
      ref={sectionRef}
      className="py-20 md:py-24 lg:py-32 px-6 bg-gray-50 dark:bg-[#0A0A0A] relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-[#F5CDB3]/5 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-[#D0ECEE]/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Section Header */}
        <div
          className={`
          text-center mb-16 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#F5CDB3]/20 border border-[#F5CDB3]/30 rounded-full px-4 py-2 mb-6">
            <Rocket size={16} className="text-[#8B6914] dark:text-[#F5CDB3]" />
            <span
              className="text-[#8B6914] dark:text-[#F5CDB3] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Pricing
            </span>
          </div>

          <h2
            className="text-[clamp(2.25rem,6vw,4rem)] leading-[1.1] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            Choose the perfect
            <br />
            <span className="relative inline-block">
              <span className="relative z-10">plan for you</span>
              <div className="absolute bottom-2 left-0 w-full h-3 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] opacity-60 -skew-x-6"></div>
            </span>
          </h2>

          <p
            className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed mb-8"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Start free and scale up as your business grows. No hidden fees,
            cancel anytime.
          </p>

          {/* Billing Toggle */}
          <div className="inline-flex items-center gap-4 bg-white dark:bg-[#1A1A1A] rounded-full p-2 shadow-lg">
            <span
              className={`px-4 py-2 text-sm font-medium transition-colors duration-200 ${
                !isYearly
                  ? "text-black dark:text-white"
                  : "text-gray-500 dark:text-gray-400"
              }`}
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Monthly
            </span>

            <button
              onClick={() => setIsYearly(!isYearly)}
              className={`
                relative w-14 h-7 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:ring-offset-2
                ${isYearly ? "bg-[#F5CDB3]" : "bg-gray-300 dark:bg-gray-600"}
              `}
            >
              <div
                className={`
                absolute top-0.5 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-200
                ${isYearly ? "translate-x-7" : "translate-x-0.5"}
              `}
              ></div>
            </button>

            <span
              className={`px-4 py-2 text-sm font-medium transition-colors duration-200 ${
                isYearly
                  ? "text-black dark:text-white"
                  : "text-gray-500 dark:text-gray-400"
              }`}
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Yearly
              <span className="ml-2 bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded-full">
                Save 20%
              </span>
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => {
            const IconComponent = plan.icon;
            const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;

            return (
              <div
                key={plan.name}
                className={`
                  relative rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105
                  ${plan.popular ? "ring-4 ring-[#F5CDB3] ring-opacity-50" : ""}
                  ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
                `}
                style={{
                  transitionDelay: `${index * 150 + 300}ms`,
                }}
              >
                {/* Popular Badge */}
                {plan.popular && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="bg-[#F5CDB3] text-black font-bold text-xs px-6 py-2 rounded-full shadow-lg">
                      MOST POPULAR
                    </div>
                  </div>
                )}

                {/* Card Background */}
                <div
                  className={`h-full bg-gradient-to-br ${plan.color} p-8 relative`}
                >
                  {/* Header */}
                  <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl mb-4">
                      <IconComponent size={32} className={plan.textColor} />
                    </div>

                    <h3
                      className={`text-2xl font-bold ${plan.textColor} mb-2`}
                      style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                    >
                      {plan.name}
                    </h3>

                    <p
                      className={`${plan.textColor} opacity-80 text-sm`}
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      {plan.description}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="text-center mb-8">
                    <div className="flex items-baseline justify-center gap-1">
                      <span
                        className={`text-5xl font-bold ${plan.textColor}`}
                        style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                      >
                        ${price}
                      </span>
                      <span
                        className={`${plan.textColor} opacity-80 text-lg font-medium`}
                      >
                        /{isYearly ? "mo" : "mo"}
                      </span>
                    </div>
                    {isYearly && (
                      <p
                        className={`${plan.textColor} opacity-70 text-sm mt-1`}
                      >
                        Billed annually (${price * 12}/year)
                      </p>
                    )}
                  </div>

                  {/* Features */}
                  <div className="space-y-4 mb-8">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div
                          className={`
                          w-6 h-6 rounded-full flex items-center justify-center
                          ${
                            feature.included
                              ? "bg-white/20 backdrop-blur-sm"
                              : "bg-black/10 dark:bg-white/10"
                          }
                        `}
                        >
                          {feature.included ? (
                            <Check
                              size={14}
                              className={plan.textColor}
                              strokeWidth={3}
                            />
                          ) : (
                            <X
                              size={14}
                              className={`${plan.textColor} opacity-40`}
                              strokeWidth={2}
                            />
                          )}
                        </div>
                        <span
                          className={`text-sm font-medium ${plan.textColor} ${
                            !feature.included ? "opacity-40 line-through" : ""
                          }`}
                          style={{ fontFamily: "Inter, sans-serif" }}
                        >
                          {feature.name}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <button
                    className={`
                    w-full font-semibold py-4 px-6 rounded-2xl transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl
                    ${plan.buttonStyle}
                  `}
                  >
                    Get Started
                  </button>

                  {/* Money-back guarantee */}
                  <p
                    className={`text-center text-xs ${plan.textColor} opacity-70 mt-4`}
                  >
                    14-day money-back guarantee
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ/Trust Section */}
        <div
          className={`
          text-center mt-16 transition-all duration-1000 ease-out delay-800
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-12 h-12 bg-[#F5CDB3]/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Check
                  size={24}
                  className="text-[#8B6914] dark:text-[#F5CDB3]"
                />
              </div>
              <h4
                className="font-semibold text-black dark:text-white mb-2"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                No Setup Fees
              </h4>
              <p
                className="text-gray-600 dark:text-gray-400 text-sm"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Get started immediately with no hidden costs or setup fees.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-[#D0ECEE]/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Rocket
                  size={24}
                  className="text-[#2A5A58] dark:text-[#B8E5E8]"
                />
              </div>
              <h4
                className="font-semibold text-black dark:text-white mb-2"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                Cancel Anytime
              </h4>
              <p
                className="text-gray-600 dark:text-gray-400 text-sm"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                No long-term contracts. Cancel or change your plan anytime.
              </p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Star
                  size={24}
                  className="text-green-600 dark:text-green-400"
                />
              </div>
              <h4
                className="font-semibold text-black dark:text-white mb-2"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                24/7 Support
              </h4>
              <p
                className="text-gray-600 dark:text-gray-400 text-sm"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Get help when you need it with our dedicated support team.
              </p>
            </div>
          </div>

          <div className="mt-12">
            <p
              className="text-gray-600 dark:text-gray-400 mb-6"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Questions about pricing?
            </p>
            <button className="bg-transparent border-2 border-[#F5CDB3] text-[#8B6914] dark:text-[#F5CDB3] font-semibold px-8 py-3 rounded-full hover:bg-[#F5CDB3] hover:text-black transition-all duration-300">
              Contact Sales
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

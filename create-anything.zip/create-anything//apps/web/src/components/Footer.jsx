"use client";

import { useState } from "react";
import {
  Mail,
  ArrowRight,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  MapPin,
  Phone,
} from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleNewsletterSubmit = async (e) => {
    e.preventDefault();

    // Simulate API call
    setTimeout(() => {
      setIsSubscribed(true);
      setEmail("");
      // Reset success state after 3 seconds
      setTimeout(() => setIsSubscribed(false), 3000);
    }, 1000);
  };

  const footerLinks = {
    Product: [
      { label: "Features", href: "#features" },
      { label: "Pricing", href: "#pricing" },
      { label: "Integrations", href: "#integrations" },
      { label: "API Documentation", href: "#api" },
      { label: "Changelog", href: "#changelog" },
    ],
    Company: [
      { label: "About Us", href: "#about" },
      { label: "Careers", href: "#careers" },
      { label: "Press Kit", href: "#press" },
      { label: "Contact", href: "#contact" },
      { label: "Partners", href: "#partners" },
    ],
    Resources: [
      { label: "Help Center", href: "#help" },
      { label: "Blog", href: "#blog" },
      { label: "Community", href: "#community" },
      { label: "Webinars", href: "#webinars" },
      { label: "Case Studies", href: "#cases" },
    ],
    Legal: [
      { label: "Privacy Policy", href: "#privacy" },
      { label: "Terms of Service", href: "#terms" },
      { label: "Cookie Policy", href: "#cookies" },
      { label: "GDPR", href: "#gdpr" },
      { label: "Security", href: "#security" },
    ],
  };

  const socialLinks = [
    { icon: Twitter, href: "https://twitter.com/sellco", label: "Twitter" },
    { icon: Facebook, href: "https://facebook.com/sellco", label: "Facebook" },
    {
      icon: Linkedin,
      href: "https://linkedin.com/company/sellco",
      label: "LinkedIn",
    },
    {
      icon: Instagram,
      href: "https://instagram.com/sellco",
      label: "Instagram",
    },
  ];

  return (
    <footer className="bg-gray-50 dark:bg-[#0A0A0A] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div className="absolute top-10 left-10 w-32 h-32 border border-[#F5CDB3] rounded-full"></div>
        <div className="absolute top-40 right-20 w-16 h-16 border border-[#D0ECEE] rounded-lg rotate-45"></div>
        <div className="absolute bottom-20 left-1/3 w-24 h-24 border border-[#E7B18E] rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 pt-16 pb-8 relative">
        {/* Main Footer Content */}
        <div className="grid lg:grid-cols-5 gap-12 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <a
                href="#"
                className="text-3xl font-bold text-black dark:text-white mb-4 inline-block"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                SellCo
              </a>
              <p
                className="text-gray-600 dark:text-gray-400 leading-relaxed max-w-md"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                The complete platform to launch, manage, and scale your
                business. Join thousands of successful entrepreneurs who trust
                our solution.
              </p>
            </div>

            {/* Newsletter Signup */}
            <div>
              <h4
                className="font-semibold text-black dark:text-white mb-3 text-lg"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                Stay updated
              </h4>
              <p
                className="text-gray-600 dark:text-gray-400 mb-4 text-sm"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Get the latest updates, tips, and exclusive offers delivered to
                your inbox.
              </p>

              {isSubscribed ? (
                <div className="flex items-center gap-2 p-4 bg-green-100 dark:bg-green-900/30 rounded-xl">
                  <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                    <ArrowRight size={12} className="text-white" />
                  </div>
                  <span className="text-green-800 dark:text-green-400 font-medium text-sm">
                    Thanks for subscribing!
                  </span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
                  <div className="flex-1">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email"
                      required
                      className="w-full px-4 py-3 bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-gray-900 dark:text-white placeholder-gray-500"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-[#F5CDB3] hover:bg-[#E7B18E] text-black p-3 rounded-xl transition-all duration-200 hover:scale-105 shadow-lg"
                  >
                    <ArrowRight size={20} />
                  </button>
                </form>
              )}
            </div>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400">
                <Mail size={16} />
                <span className="text-sm">hello@sellco.com</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400">
                <Phone size={16} />
                <span className="text-sm">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400">
                <MapPin size={16} />
                <span className="text-sm">San Francisco, CA</span>
              </div>
            </div>
          </div>

          {/* Links Columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4
                className="font-semibold text-black dark:text-white mb-4"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                {category}
              </h4>
              <ul className="space-y-3">
                {links.map((link, index) => (
                  <li key={index}>
                    <a
                      href={link.href}
                      className="text-gray-600 dark:text-gray-400 hover:text-[#F5CDB3] dark:hover:text-[#F5CDB3] transition-colors duration-200 text-sm"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="border-t border-gray-200 dark:border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            {/* Left - Copyright */}
            <div className="flex flex-col md:flex-row items-center gap-4">
              <p
                className="text-gray-500 dark:text-gray-400 text-sm"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                © 2024 SellCo. All rights reserved.
              </p>

              {/* Trust Badges */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 bg-gray-200 dark:bg-gray-800 px-3 py-1 rounded-full">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-xs text-gray-600 dark:text-gray-400 font-medium">
                    SOC 2 Compliant
                  </span>
                </div>
                <div className="flex items-center gap-2 bg-gray-200 dark:bg-gray-800 px-3 py-1 rounded-full">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-xs text-gray-600 dark:text-gray-400 font-medium">
                    GDPR Ready
                  </span>
                </div>
              </div>
            </div>

            {/* Right - Social Links */}
            <div className="flex items-center gap-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-gray-700 rounded-xl flex items-center justify-center text-gray-600 dark:text-gray-400 hover:text-[#F5CDB3] dark:hover:text-[#F5CDB3] hover:bg-[#F5CDB3]/10 dark:hover:bg-[#F5CDB3]/10 hover:border-[#F5CDB3]/50 transition-all duration-200 hover:scale-110"
                  >
                    <IconComponent size={18} />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Bottom Note */}
          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-800">
            <div className="text-center">
              <p
                className="text-gray-500 dark:text-gray-400 text-xs leading-relaxed"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Made with ❤️ in San Francisco. SellCo is a registered trademark.
                All product names, logos, and brands are property of their
                respective owners.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Back to Top Button */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="fixed bottom-8 right-8 w-12 h-12 bg-[#F5CDB3] hover:bg-[#E7B18E] text-black rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 flex items-center justify-center z-40"
        aria-label="Back to top"
      >
        <ArrowRight size={20} className="-rotate-90" />
      </button>
    </footer>
  );
}

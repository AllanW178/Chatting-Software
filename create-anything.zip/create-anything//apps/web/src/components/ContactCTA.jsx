"use client";

import { useState, useRef, useEffect } from "react";
import {
  ArrowUpRight,
  Send,
  CheckCircle,
  Phone,
  Mail,
  MessageSquare,
} from "lucide-react";

export default function ContactCTA() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setIsSubmitted(true);
        setFormData({ name: "", email: "", company: "", message: "" });
      }
    } catch (error) {
      console.error("Contact form error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="py-20 md:py-24 lg:py-32 px-6 bg-white dark:bg-[#121212] relative overflow-hidden"
    >
      {/* Decorative Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Floating Geometric Shapes */}
        <div className="absolute top-20 left-10 w-16 h-16 border-2 border-[#F5CDB3]/30 rounded-lg rotate-45 animate-pulse"></div>
        <div
          className="absolute bottom-40 right-20 w-12 h-12 bg-[#D0ECEE]/20 rounded-full animate-bounce"
          style={{ animationDelay: "1s" }}
        ></div>
        <div
          className="absolute top-1/2 left-20 w-8 h-8 border-2 border-[#E7B18E]/40 rounded-full animate-ping"
          style={{ animationDelay: "2s" }}
        ></div>

        {/* Background Gradient Orbs */}
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-gradient-to-r from-[#F5CDB3]/10 to-[#E7B18E]/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-gradient-to-l from-[#D0ECEE]/10 to-[#B8E5E8]/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Section Header */}
        <div
          className={`
          text-center mb-16 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#D0ECEE]/20 border border-[#D0ECEE]/30 rounded-full px-4 py-2 mb-6">
            <MessageSquare
              size={16}
              className="text-[#2A5A58] dark:text-[#B8E5E8]"
            />
            <span
              className="text-[#2A5A58] dark:text-[#B8E5E8] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Get in Touch
            </span>
          </div>

          <h2
            className="text-[clamp(2.5rem,8vw,5.5rem)] leading-[0.9] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            Ready to transform
            <br />
            <span className="relative inline-block">
              <span className="relative z-10">your business?</span>
              <div className="absolute bottom-2 left-0 w-full h-4 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] opacity-80 -skew-x-6 animate-pulse"></div>
            </span>
          </h2>

          <p
            className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Join thousands of successful businesses. Start your free trial today
            or get in touch to learn how we can help you grow.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left Side - Contact Information & CTA */}
          <div
            className={`
            space-y-12 transition-all duration-1000 ease-out delay-300
            ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"}
          `}
          >
            {/* Main CTA Card */}
            <div className="bg-gradient-to-br from-[#F5CDB3] to-[#E7B18E] rounded-3xl p-8 md:p-12 text-black relative overflow-hidden">
              {/* Decorative Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-4 right-4 w-20 h-20 border border-black/20 rounded-full"></div>
                <div className="absolute bottom-8 left-8 w-16 h-16 border border-black/20 rounded-lg rotate-45"></div>
              </div>

              <div className="relative z-10">
                <h3
                  className="text-3xl md:text-4xl font-bold mb-6 leading-tight"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  Start your free trial
                  <br />
                  in 30 seconds
                </h3>

                <p
                  className="text-lg mb-8 opacity-90 leading-relaxed"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  No credit card required. Full access to all features. Cancel
                  anytime. Join 50,000+ businesses that trust our platform.
                </p>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <CheckCircle size={20} className="text-black" />
                    <span className="font-medium">14-day free trial</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle size={20} className="text-black" />
                    <span className="font-medium">No setup fees</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle size={20} className="text-black" />
                    <span className="font-medium">24/7 support included</span>
                  </div>
                </div>

                <button className="group w-full bg-black text-white font-semibold py-4 px-8 rounded-2xl hover:bg-gray-800 transition-all duration-300 hover:scale-105 shadow-xl flex items-center justify-center gap-3">
                  <span>Start Free Trial</span>
                  <ArrowUpRight
                    size={20}
                    className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-200"
                  />
                </button>
              </div>
            </div>

            {/* Contact Methods */}
            <div className="space-y-6">
              <h4
                className="text-xl font-bold text-black dark:text-white mb-6"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                Or get in touch directly
              </h4>

              <div className="grid gap-4">
                <a
                  href="mailto:hello@sellco.com"
                  className="group flex items-center gap-4 p-4 bg-gray-50 dark:bg-[#1A1A1A] rounded-2xl hover:bg-[#F5CDB3]/10 dark:hover:bg-[#F5CDB3]/5 transition-all duration-200 hover:scale-105"
                >
                  <div className="w-12 h-12 bg-[#F5CDB3]/20 rounded-2xl flex items-center justify-center group-hover:bg-[#F5CDB3] transition-colors duration-200">
                    <Mail
                      size={20}
                      className="text-[#8B6914] group-hover:text-black"
                    />
                  </div>
                  <div>
                    <div className="font-semibold text-black dark:text-white">
                      Email us
                    </div>
                    <div className="text-gray-600 dark:text-gray-400">
                      hello@sellco.com
                    </div>
                  </div>
                </a>

                <a
                  href="tel:+1-555-123-4567"
                  className="group flex items-center gap-4 p-4 bg-gray-50 dark:bg-[#1A1A1A] rounded-2xl hover:bg-[#D0ECEE]/10 dark:hover:bg-[#D0ECEE]/5 transition-all duration-200 hover:scale-105"
                >
                  <div className="w-12 h-12 bg-[#D0ECEE]/20 rounded-2xl flex items-center justify-center group-hover:bg-[#D0ECEE] transition-colors duration-200">
                    <Phone
                      size={20}
                      className="text-[#2A5A58] group-hover:text-black"
                    />
                  </div>
                  <div>
                    <div className="font-semibold text-black dark:text-white">
                      Call us
                    </div>
                    <div className="text-gray-600 dark:text-gray-400">
                      +1 (555) 123-4567
                    </div>
                  </div>
                </a>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div
                  className="text-3xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  &lt; 24h
                </div>
                <div className="text-gray-600 dark:text-gray-400 text-sm">
                  Response Time
                </div>
              </div>
              <div className="text-center">
                <div
                  className="text-3xl font-bold text-black dark:text-white mb-2"
                  style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                >
                  99.9%
                </div>
                <div className="text-gray-600 dark:text-gray-400 text-sm">
                  Uptime SLA
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Contact Form */}
          <div
            className={`
            transition-all duration-1000 ease-out delay-500
            ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}
          `}
          >
            <div className="bg-white dark:bg-[#1A1A1A] rounded-3xl p-8 md:p-12 shadow-2xl border border-gray-100 dark:border-gray-800">
              {isSubmitted ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle
                      size={40}
                      className="text-green-600 dark:text-green-400"
                    />
                  </div>
                  <h3
                    className="text-2xl font-bold text-black dark:text-white mb-4"
                    style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                  >
                    Message sent successfully!
                  </h3>
                  <p
                    className="text-gray-600 dark:text-gray-400 mb-8"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    Thank you for reaching out. We'll get back to you within 24
                    hours.
                  </p>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-semibold px-8 py-3 rounded-xl transition-colors duration-200"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-8">
                    <h3
                      className="text-2xl font-bold text-black dark:text-white mb-4"
                      style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                    >
                      Send us a message
                    </h3>
                    <p
                      className="text-gray-600 dark:text-gray-400"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      Tell us about your project and we'll get back to you with
                      a customized solution.
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label
                          htmlFor="name"
                          className="block text-sm font-medium text-black dark:text-white mb-2"
                          style={{ fontFamily: "Inter, sans-serif" }}
                        >
                          Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          required
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-black dark:text-white transition-all duration-200"
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="email"
                          className="block text-sm font-medium text-black dark:text-white mb-2"
                          style={{ fontFamily: "Inter, sans-serif" }}
                        >
                          Email *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          required
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-black dark:text-white transition-all duration-200"
                          placeholder="your@email.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="company"
                        className="block text-sm font-medium text-black dark:text-white mb-2"
                        style={{ fontFamily: "Inter, sans-serif" }}
                      >
                        Company
                      </label>
                      <input
                        type="text"
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-black dark:text-white transition-all duration-200"
                        placeholder="Your company"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="message"
                        className="block text-sm font-medium text-black dark:text-white mb-2"
                        style={{ fontFamily: "Inter, sans-serif" }}
                      >
                        Message *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        required
                        rows="5"
                        value={formData.message}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-black dark:text-white transition-all duration-200 resize-none"
                        placeholder="Tell us about your project..."
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={`
                        w-full font-semibold py-4 px-8 rounded-xl transition-all duration-300 hover:scale-105 shadow-lg flex items-center justify-center gap-3
                        ${
                          isSubmitting
                            ? "bg-gray-400 cursor-not-allowed"
                            : "bg-[#F5CDB3] hover:bg-[#E7B18E] hover:shadow-xl"
                        } text-black
                      `}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                          <span>Sending...</span>
                        </>
                      ) : (
                        <>
                          <Send size={20} />
                          <span>Send Message</span>
                        </>
                      )}
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

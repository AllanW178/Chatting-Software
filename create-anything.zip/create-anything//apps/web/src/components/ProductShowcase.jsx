"use client";

import { useState, useRef, useEffect } from "react";
import {
  Package,
  Zap,
  Palette,
  Code,
  ArrowUpRight,
  Star,
  Users,
  TrendingUp,
} from "lucide-react";

export default function ProductShowcase() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const products = [
    {
      id: 1,
      category: "E-commerce",
      title: "Online Store Builder",
      description:
        "Create stunning online stores that convert visitors into customers with our drag-and-drop builder.",
      longDescription:
        "Our e-commerce platform combines beautiful design with powerful functionality. Build product catalogs, manage inventory, process payments, and track orders all in one place. Perfect for businesses of any size looking to sell online.",
      icon: Package,
      color: "from-[#F5CDB3] to-[#E7B18E]",
      image:
        "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop&auto=format&q=80",
      features: [
        "Drag & Drop Builder",
        "Payment Processing",
        "Inventory Management",
        "Mobile Responsive",
      ],
      stats: { users: "50K+", rating: 4.9, growth: "+150%" },
    },
    {
      id: 2,
      category: "Marketing",
      title: "Campaign Manager",
      description:
        "Launch and optimize marketing campaigns across multiple channels with AI-powered insights.",
      longDescription:
        "Take your marketing to the next level with automated campaign management. Create email sequences, social media campaigns, and targeted ads that reach the right audience at the right time. Our AI helps optimize for maximum ROI.",
      icon: Zap,
      color: "from-[#D0ECEE] to-[#B8E5E8]",
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop&auto=format&q=80",
      features: [
        "Multi-channel Campaigns",
        "A/B Testing",
        "Analytics Dashboard",
        "Automation",
      ],
      stats: { users: "25K+", rating: 4.8, growth: "+200%" },
    },
    {
      id: 3,
      category: "Design",
      title: "Brand Studio",
      description:
        "Design consistent brand experiences with our comprehensive brand management tools.",
      longDescription:
        "Maintain brand consistency across all touchpoints with our brand management suite. Create logos, define color palettes, manage assets, and ensure every piece of content aligns with your brand identity.",
      icon: Palette,
      color: "from-[#FFE5E5] to-[#FFD1D1]",
      image:
        "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=400&fit=crop&auto=format&q=80",
      features: [
        "Logo Designer",
        "Brand Guidelines",
        "Asset Library",
        "Style Guide",
      ],
      stats: { users: "15K+", rating: 4.7, growth: "+180%" },
    },
    {
      id: 4,
      category: "Development",
      title: "Website Builder",
      description:
        "Build professional websites without code using our intuitive visual editor and templates.",
      longDescription:
        "Create stunning websites with zero coding required. Choose from hundreds of templates, customize with our visual editor, and launch your site in minutes. Optimized for speed and SEO out of the box.",
      icon: Code,
      color: "from-[#E8F4FD] to-[#D1E9FB]",
      image:
        "https://images.unsplash.com/photo-1547658719-da2b51169166?w=600&h=400&fit=crop&auto=format&q=80",
      features: [
        "Visual Editor",
        "SEO Optimized",
        "Custom Domain",
        "Analytics",
      ],
      stats: { users: "40K+", rating: 4.9, growth: "+220%" },
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="products"
      ref={sectionRef}
      className="py-20 md:py-24 lg:py-32 px-6 bg-white dark:bg-[#121212] relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-40 -left-20 w-40 h-40 bg-[#F5CDB3]/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 -right-20 w-60 h-60 bg-[#D0ECEE]/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Section Header */}
        <div
          className={`
          text-center mb-16 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#D0ECEE]/20 border border-[#D0ECEE]/30 rounded-full px-4 py-2 mb-6">
            <Package size={16} className="text-[#2A5A58] dark:text-[#B8E5E8]" />
            <span
              className="text-[#2A5A58] dark:text-[#B8E5E8] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Products
            </span>
          </div>

          <h2
            className="text-[clamp(2.25rem,6vw,4rem)] leading-[1.1] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            Powerful tools for
            <br />
            <span className="relative inline-block">
              <span className="relative z-10">every need</span>
              <div className="absolute bottom-2 left-0 w-full h-3 bg-gradient-to-r from-[#D0ECEE] to-[#B8E5E8] opacity-60 -skew-x-6"></div>
            </span>
          </h2>

          <p
            className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            From e-commerce to marketing, design to development - we have the
            tools to help your business thrive.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {products.map((product, index) => {
            const IconComponent = product.icon;
            return (
              <div
                key={product.id}
                className={`
                  group relative bg-white dark:bg-[#1A1A1A] rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl 
                  transition-all duration-500 hover:scale-105 cursor-pointer
                  ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
                `}
                style={{
                  transitionDelay: `${index * 150 + 300}ms`,
                }}
              >
                {/* Image Header */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />

                  {/* Gradient Overlay */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${product.color} opacity-80`}
                  ></div>

                  {/* Icon */}
                  <div className="absolute top-4 left-4">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                      <IconComponent size={24} className="text-white" />
                    </div>
                  </div>

                  {/* Stats Badge */}
                  <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-lg p-2">
                    <div className="flex items-center gap-1 text-white text-xs font-medium">
                      <Star size={12} className="fill-current" />
                      <span>{product.stats.rating}</span>
                    </div>
                  </div>

                  {/* Category Badge */}
                  <div className="absolute bottom-4 left-4">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-3 py-1 rounded-full">
                      {product.category}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="mb-4">
                    <h3
                      className="text-xl font-bold text-black dark:text-white mb-2 group-hover:text-[#2A5A58] dark:group-hover:text-[#B8E5E8] transition-colors duration-300"
                      style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                    >
                      {product.title}
                    </h3>

                    <p
                      className="text-gray-600 dark:text-gray-400 leading-relaxed text-sm"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      {product.description}
                    </p>
                  </div>

                  {/* Features List */}
                  <div className="mb-6">
                    <div className="grid grid-cols-2 gap-2">
                      {product.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <div className="w-1 h-1 bg-[#D0ECEE] rounded-full"></div>
                          <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bottom Stats & CTA */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <Users size={14} className="text-gray-400" />
                        <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                          {product.stats.users}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp size={14} className="text-green-500" />
                        <span className="text-xs text-green-600 font-medium">
                          {product.stats.growth}
                        </span>
                      </div>
                    </div>

                    <button className="group/btn flex items-center gap-2 text-[#2A5A58] dark:text-[#B8E5E8] font-medium text-sm hover:text-black dark:hover:text-white transition-colors duration-200">
                      <span>Learn More</span>
                      <ArrowUpRight
                        size={16}
                        className="group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform duration-200"
                      />
                    </button>
                  </div>
                </div>

                {/* Hover Expanded Content */}
                <div className="absolute inset-0 bg-white dark:bg-[#1A1A1A] p-6 flex flex-col justify-center translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out">
                  <div className="text-center">
                    <div className="mb-4">
                      <div
                        className={`w-16 h-16 bg-gradient-to-r ${product.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}
                      >
                        <IconComponent size={32} className="text-white" />
                      </div>

                      <h3
                        className="text-2xl font-bold text-black dark:text-white mb-3"
                        style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                      >
                        {product.title}
                      </h3>

                      <p
                        className="text-gray-600 dark:text-gray-400 leading-relaxed text-sm mb-6"
                        style={{ fontFamily: "Inter, sans-serif" }}
                      >
                        {product.longDescription}
                      </p>
                    </div>

                    <div className="space-y-3">
                      <button className="w-full bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-semibold py-3 px-6 rounded-xl transition-colors duration-200">
                        Get Started
                      </button>
                      <button className="w-full bg-transparent border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-[#2A2A2A] font-medium py-2 px-6 rounded-xl transition-colors duration-200">
                        View Demo
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div
          className={`
          text-center mt-16 transition-all duration-1000 ease-out delay-800
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          <p
            className="text-gray-600 dark:text-gray-400 mb-6"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Ready to transform your business?
          </p>
          <button className="bg-black dark:bg-white text-white dark:text-black font-semibold px-8 py-4 rounded-full hover:bg-[#F5CDB3] hover:text-black dark:hover:bg-[#F5CDB3] dark:hover:text-black transition-all duration-300 hover:scale-105 shadow-lg">
            Explore All Products
          </button>
        </div>
      </div>
    </section>
  );
}

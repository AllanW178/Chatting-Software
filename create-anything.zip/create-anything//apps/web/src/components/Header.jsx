"use client";

import { useState, useEffect } from "react";
import { Mail, Menu, X } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const navItems = [
    { label: "Features", href: "#features" },
    { label: "Products", href: "#products" },
    { label: "Pricing", href: "#pricing" },
    { label: "Testimonials", href: "#testimonials" },
    { label: "Contact", href: "#contact" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`
      fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-out
      ${
        scrolled
          ? "bg-white/95 dark:bg-[#121212]/95 backdrop-blur-md shadow-sm"
          : "bg-white dark:bg-[#121212]"
      }
    `}
    >
      <div className="max-w-7xl mx-auto px-8 md:px-10 py-4">
        <div className="flex items-center justify-between">
          {/* Left group - Logo & Contact */}
          <div className="flex items-center gap-6">
            {/* Logo */}
            <a
              href="#"
              className="text-2xl font-bold text-black dark:text-white transition-colors"
              style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
            >
              SellCo
            </a>

            {/* Contact badge (hidden on mobile) */}
            <div className="hidden md:flex items-center gap-3">
              <a
                href="mailto:hello@sellco.com"
                className="w-10 h-10 rounded-full border border-[#F2F2F2] dark:border-[#333333] bg-transparent flex items-center justify-center cursor-pointer hover:border-gray-300 dark:hover:border-[#444444] transition-all duration-200 hover:scale-105"
              >
                <Mail
                  size={18}
                  className="text-black dark:text-white"
                  strokeWidth={2}
                />
              </a>

              <a
                href="mailto:hello@sellco.com"
                className="text-black dark:text-white font-semibold text-[15px] hover:opacity-80 transition-opacity cursor-pointer"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                hello@sellco.com
              </a>
            </div>
          </div>

          {/* Right group - Navigation (desktop) */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item, index) => (
              <a
                key={index}
                href={item.href}
                className="text-black/90 dark:text-white/90 font-semibold text-[15px] hover:text-black dark:hover:text-white relative group transition-all duration-200 cursor-pointer"
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                {item.label}
                <span className="absolute left-0 -bottom-1 w-0 h-0.5 bg-[#F5CDB3] dark:bg-[#D4A574] group-hover:w-full transition-all duration-200"></span>
              </a>
            ))}

            {/* CTA Button */}
            <button className="bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-medium text-sm px-6 py-3 rounded-full transition-all duration-200 hover:scale-105 hover:shadow-lg">
              Get Started
            </button>
          </nav>

          {/* Hamburger menu (mobile) */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden w-10 h-10 flex items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-[#1E1E1E] transition-colors duration-150 rounded-md"
          >
            {isMenuOpen ? (
              <X
                size={24}
                className="text-black dark:text-white"
                strokeWidth={2}
              />
            ) : (
              <Menu
                size={24}
                className="text-black dark:text-white"
                strokeWidth={2}
              />
            )}
          </button>
        </div>

        {/* Mobile menu dropdown */}
        <div
          className={`
          lg:hidden overflow-hidden transition-all duration-300 ease-out
          ${isMenuOpen ? "max-h-96 opacity-100 mt-4" : "max-h-0 opacity-0"}
        `}
        >
          <div className="py-4 border-t border-[#F2F2F2] dark:border-[#333333]">
            <nav className="flex flex-col gap-4">
              {navItems.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-black/90 dark:text-white/90 font-semibold text-[15px] hover:text-black dark:hover:text-white transition-colors cursor-pointer py-2"
                  style={{ fontFamily: "Montserrat, sans-serif" }}
                >
                  {item.label}
                </a>
              ))}
              <div className="pt-4 border-t border-[#F2F2F2] dark:border-[#333333] mt-2">
                <button className="w-full bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-medium text-sm px-6 py-3 rounded-full transition-all duration-200">
                  Get Started
                </button>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
}

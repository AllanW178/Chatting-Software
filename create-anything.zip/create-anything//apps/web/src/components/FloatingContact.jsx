"use client";

import { useState, useEffect } from "react";
import {
  MessageCircle,
  X,
  Send,
  Phone,
  Mail,
  ArrowUpRight,
} from "lucide-react";

export default function FloatingContact() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show the widget after a delay when page loads
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (message.trim()) {
      // In a real app, this would send the message to your chat system
      console.log("Sending message:", message);
      setMessage("");
      setIsOpen(false);

      // Show success state or redirect to contact page
      // For now, we'll just close the widget
    }
  };

  const quickActions = [
    {
      icon: Phone,
      label: "Call us",
      action: () => window.open("tel:+1-555-123-4567"),
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      icon: Mail,
      label: "Email us",
      action: () => window.open("mailto:hello@sellco.com"),
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      icon: ArrowUpRight,
      label: "Book demo",
      action: () => {
        const contactSection = document.getElementById("contact");
        contactSection?.scrollIntoView({ behavior: "smooth" });
        setIsOpen(false);
      },
      color: "bg-purple-500 hover:bg-purple-600",
    },
  ];

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 left-6 z-50">
      {/* Main Chat Widget */}
      <div
        className={`
        transition-all duration-300 ease-out
        ${isOpen ? "mb-4" : "mb-0"}
      `}
      >
        {/* Chat Panel */}
        <div
          className={`
          bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 w-80 
          transform transition-all duration-300 ease-out origin-bottom-left
          ${isOpen ? "scale-100 opacity-100 translate-y-0" : "scale-95 opacity-0 translate-y-4 pointer-events-none"}
        `}
        >
          {/* Header */}
          <div className="p-4 border-b border-gray-100 dark:border-gray-700 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] rounded-t-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <MessageCircle size={20} className="text-black" />
                </div>
                <div>
                  <h3
                    className="font-semibold text-black text-sm"
                    style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                  >
                    Need help?
                  </h3>
                  <p className="text-black/80 text-xs">
                    We're here to assist you
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-white/20 flex items-center justify-center transition-colors duration-200"
              >
                <X size={16} className="text-black" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-4">
            {/* Welcome Message */}
            <div className="mb-4">
              <div className="bg-gray-50 dark:bg-[#2A2A2A] rounded-xl p-3 mb-3">
                <p
                  className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  👋 Hi there! How can we help you today?
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-2 mb-4">
              <p
                className="text-xs text-gray-500 dark:text-gray-400 font-medium uppercase tracking-wide mb-2"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Quick Actions
              </p>
              {quickActions.map((action, index) => {
                const IconComponent = action.icon;
                return (
                  <button
                    key={index}
                    onClick={action.action}
                    className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-[#2A2A2A] transition-colors duration-200 text-left group"
                  >
                    <div
                      className={`w-8 h-8 ${action.color} rounded-lg flex items-center justify-center transition-transform duration-200 group-hover:scale-110`}
                    >
                      <IconComponent size={14} className="text-white" />
                    </div>
                    <span
                      className="text-sm text-gray-700 dark:text-gray-300 font-medium"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      {action.label}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Message Form */}
            <div>
              <p
                className="text-xs text-gray-500 dark:text-gray-400 font-medium uppercase tracking-wide mb-2"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Or send us a message
              </p>
              <form onSubmit={handleSendMessage}>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 px-3 py-2 bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-sm text-gray-900 dark:text-white placeholder-gray-500"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  />
                  <button
                    type="submit"
                    disabled={!message.trim()}
                    className="w-8 h-8 bg-[#F5CDB3] hover:bg-[#E7B18E] disabled:bg-gray-300 disabled:cursor-not-allowed text-black rounded-lg flex items-center justify-center transition-all duration-200 hover:scale-105"
                  >
                    <Send size={14} />
                  </button>
                </div>
              </form>
            </div>

            {/* Footer Note */}
            <p
              className="text-xs text-gray-400 dark:text-gray-500 mt-3 text-center"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Typically replies in a few minutes
            </p>
          </div>
        </div>
      </div>

      {/* Floating Button */}
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`
            w-14 h-14 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] hover:from-[#E7B18E] hover:to-[#D4A574] 
            text-black rounded-full shadow-lg hover:shadow-xl 
            flex items-center justify-center
            transition-all duration-300 hover:scale-110
            ${isOpen ? "rotate-180" : "rotate-0"}
          `}
          aria-label={isOpen ? "Close chat" : "Open chat"}
        >
          {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
        </button>

        {/* Notification Dot */}
        {!isOpen && (
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">1</span>
          </div>
        )}

        {/* Pulse Animation */}
        {!isOpen && (
          <div className="absolute inset-0 rounded-full bg-[#F5CDB3] animate-ping opacity-20"></div>
        )}
      </div>

      {/* Introduction Toast */}
      {isVisible && !isOpen && (
        <div className="absolute bottom-16 left-0 bg-white dark:bg-[#1A1A1A] rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-3 max-w-xs animate-bounce">
          <div className="flex items-start gap-2">
            <div className="w-8 h-8 bg-[#F5CDB3] rounded-full flex items-center justify-center flex-shrink-0">
              <MessageCircle size={14} className="text-black" />
            </div>
            <div>
              <p
                className="text-sm font-medium text-gray-900 dark:text-white"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                Need help getting started?
              </p>
              <p
                className="text-xs text-gray-500 dark:text-gray-400"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Chat with our team!
              </p>
            </div>
          </div>

          {/* Small Arrow pointing to button */}
          <div className="absolute bottom-0 left-6 transform translate-y-1">
            <div className="w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white dark:border-t-[#1A1A1A]"></div>
          </div>
        </div>
      )}
    </div>
  );
}

"use client";

import { useState, useRef, useEffect } from "react";
import { ChevronDown, HelpCircle, Search } from "lucide-react";

export default function FAQ() {
  const [openItems, setOpenItems] = useState(new Set([0])); // First item open by default
  const [searchTerm, setSearchTerm] = useState("");
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const faqItems = [
    {
      id: 0,
      category: "Getting Started",
      question: "How do I get started with the platform?",
      answer:
        "Getting started is simple! Sign up for a free account, choose your plan, and follow our guided setup process. You'll be up and running in minutes. Our onboarding team will help you import your data and configure the platform to match your business needs.",
    },
    {
      id: 1,
      category: "Pricing",
      question: "What are your pricing options?",
      answer:
        "We offer three flexible pricing tiers: Starter ($19/month), Professional ($49/month), and Enterprise ($99/month). All plans include a 14-day free trial, and you can upgrade or downgrade at any time. Annual billing saves you 20% on any plan.",
    },
    {
      id: 2,
      category: "Features",
      question: "What features are included in each plan?",
      answer:
        "Our Starter plan includes basic analytics, email support, and up to 3 websites. Professional adds advanced analytics, priority support, custom domains, and A/B testing. Enterprise includes everything plus unlimited websites, 24/7 phone support, API access, and white-label options.",
    },
    {
      id: 3,
      category: "Technical",
      question: "How do I integrate with my existing tools?",
      answer:
        "Our platform offers seamless integrations with over 100+ popular tools including CRMs, email marketing platforms, payment processors, and analytics tools. We provide APIs, webhooks, and pre-built connectors. Our technical team can assist with custom integrations if needed.",
    },
    {
      id: 4,
      category: "Support",
      question: "What kind of support do you provide?",
      answer:
        "We provide comprehensive support including email support for all plans, priority email support for Professional users, and 24/7 phone support for Enterprise customers. We also offer extensive documentation, video tutorials, webinars, and a community forum.",
    },
    {
      id: 5,
      category: "Security",
      question: "How secure is my data?",
      answer:
        "Security is our top priority. We use bank-level encryption (AES-256), conduct regular security audits, maintain SOC 2 compliance, and store data in secure, redundant data centers. We also offer two-factor authentication and single sign-on (SSO) options.",
    },
    {
      id: 6,
      category: "Account",
      question: "Can I cancel my subscription anytime?",
      answer:
        "Yes, you can cancel your subscription at any time with no cancellation fees. Your account will remain active until the end of your current billing period. You can also pause your subscription for up to 3 months if you need a temporary break.",
    },
    {
      id: 7,
      category: "Technical",
      question: "Do you offer custom development services?",
      answer:
        "Yes, our Enterprise plan includes access to our professional services team for custom development, data migration, and specialized integrations. We can build custom features, workflows, and integrations to meet your specific business requirements.",
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const toggleItem = (itemId) => {
    const newOpenItems = new Set(openItems);
    if (newOpenItems.has(itemId)) {
      newOpenItems.delete(itemId);
    } else {
      newOpenItems.add(itemId);
    }
    setOpenItems(newOpenItems);
  };

  const filteredFAQs = faqItems.filter(
    (item) =>
      item.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const categories = [...new Set(faqItems.map((item) => item.category))];

  return (
    <section
      ref={sectionRef}
      className="py-20 md:py-24 lg:py-32 px-6 bg-gray-50 dark:bg-[#0A0A0A] relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 right-10 w-32 h-32 bg-[#F5CDB3]/5 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 left-10 w-48 h-48 bg-[#D0ECEE]/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-4xl mx-auto relative">
        {/* Section Header */}
        <div
          className={`
          text-center mb-16 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#F5CDB3]/20 border border-[#F5CDB3]/30 rounded-full px-4 py-2 mb-6">
            <HelpCircle
              size={16}
              className="text-[#8B6914] dark:text-[#F5CDB3]"
            />
            <span
              className="text-[#8B6914] dark:text-[#F5CDB3] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              FAQ
            </span>
          </div>

          <h2
            className="text-[clamp(2.25rem,6vw,4rem)] leading-[1.1] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            Frequently asked
            <br />
            <span className="relative inline-block">
              <span className="relative z-10">questions</span>
              <div className="absolute bottom-2 left-0 w-full h-3 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] opacity-60 -skew-x-6"></div>
            </span>
          </h2>

          <p
            className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed mb-8"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Got questions? We've got answers. Find everything you need to know
            about our platform.
          </p>

          {/* Search Bar */}
          <div className="relative max-w-md mx-auto">
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
              <Search size={20} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search questions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-6 py-4 bg-white dark:bg-[#1A1A1A] border border-gray-200 dark:border-gray-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:border-transparent text-gray-900 dark:text-white placeholder-gray-500 transition-all duration-200"
              style={{ fontFamily: "Inter, sans-serif" }}
            />
          </div>
        </div>

        {/* Category Pills */}
        <div
          className={`
          flex flex-wrap justify-center gap-2 mb-12 transition-all duration-1000 ease-out delay-200
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() =>
                setSearchTerm(searchTerm === category ? "" : category)
              }
              className={`
                px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 hover:scale-105
                ${
                  searchTerm === category
                    ? "bg-[#F5CDB3] text-black"
                    : "bg-white dark:bg-[#1A1A1A] text-gray-600 dark:text-gray-300 hover:bg-[#F5CDB3]/10"
                }
              `}
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              {category}
            </button>
          ))}
        </div>

        {/* FAQ Accordion */}
        <div
          className={`
          space-y-6 transition-all duration-1000 ease-out delay-400
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          {filteredFAQs.length > 0 ? (
            filteredFAQs.map((item, index) => {
              const isOpen = openItems.has(item.id);
              return (
                <div
                  key={item.id}
                  className="group bg-white dark:bg-[#1A1A1A] rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
                  style={{
                    animationDelay: `${index * 100}ms`,
                  }}
                >
                  {/* Question Header */}
                  <button
                    onClick={() => toggleItem(item.id)}
                    className="w-full text-left p-6 md:p-8 flex items-center justify-between group hover:bg-gray-50 dark:hover:bg-[#2A2A2A] transition-colors duration-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#F5CDB3] focus:ring-offset-2"
                    aria-expanded={isOpen}
                    aria-controls={`answer-${item.id}`}
                  >
                    <div className="flex-1 pr-6">
                      {/* Category Badge */}
                      <div className="inline-flex items-center gap-2 mb-3">
                        <span className="bg-[#F5CDB3]/20 text-[#8B6914] dark:text-[#F5CDB3] text-xs font-medium px-3 py-1 rounded-full">
                          {item.category}
                        </span>
                      </div>

                      <h3
                        className="font-bold text-lg md:text-xl text-black dark:text-white leading-tight group-hover:text-[#2A5A58] dark:group-hover:text-[#B8E5E8] transition-colors duration-200"
                        style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
                      >
                        {item.question}
                      </h3>
                    </div>

                    <div
                      className={`
                      w-10 h-10 rounded-full bg-[#F5CDB3]/10 flex items-center justify-center transition-all duration-300 group-hover:bg-[#F5CDB3]/20
                      ${isOpen ? "rotate-180" : "rotate-0"}
                    `}
                    >
                      <ChevronDown
                        size={20}
                        className="text-[#8B6914] dark:text-[#F5CDB3]"
                      />
                    </div>
                  </button>

                  {/* Answer Content */}
                  <div
                    id={`answer-${item.id}`}
                    className={`
                      overflow-hidden transition-all duration-300 ease-out
                      ${isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"}
                    `}
                  >
                    <div className="px-6 md:px-8 pb-6 md:pb-8">
                      <div className="border-t border-gray-100 dark:border-gray-700 pt-6">
                        <p
                          className="text-gray-600 dark:text-gray-300 leading-relaxed"
                          style={{ fontFamily: "Inter, sans-serif" }}
                        >
                          {item.answer}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Search size={32} className="text-gray-400" />
              </div>
              <h3
                className="text-xl font-semibold text-black dark:text-white mb-2"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                No questions found
              </h3>
              <p
                className="text-gray-600 dark:text-gray-400"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                Try searching with different keywords or browse all categories.
              </p>
              <button
                onClick={() => setSearchTerm("")}
                className="mt-4 bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-medium px-6 py-3 rounded-xl transition-colors duration-200"
              >
                Clear Search
              </button>
            </div>
          )}
        </div>

        {/* Bottom CTA */}
        <div
          className={`
          text-center mt-16 transition-all duration-1000 ease-out delay-600
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          <div className="bg-gradient-to-r from-[#F5CDB3]/10 to-[#D0ECEE]/10 rounded-2xl p-8 md:p-12">
            <h3
              className="text-2xl md:text-3xl font-bold text-black dark:text-white mb-4"
              style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
            >
              Still have questions?
            </h3>
            <p
              className="text-gray-600 dark:text-gray-400 mb-8 max-w-2xl mx-auto"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Our support team is here to help you succeed. Get in touch and
              we'll get back to you within 24 hours.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-[#F5CDB3] hover:bg-[#E7B18E] text-black font-semibold px-8 py-4 rounded-xl transition-all duration-300 hover:scale-105 shadow-lg">
                Contact Support
              </button>
              <button className="bg-transparent border-2 border-[#F5CDB3] text-[#8B6914] dark:text-[#F5CDB3] font-semibold px-8 py-4 rounded-xl hover:bg-[#F5CDB3] hover:text-black transition-all duration-300">
                Schedule a Demo
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

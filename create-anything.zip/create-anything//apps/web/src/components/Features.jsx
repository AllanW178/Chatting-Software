"use client";

import { useState, useRef, useEffect } from "react";
import {
  BarChart,
  Users,
  Zap,
  Shield,
  Globe,
  Smartphone,
  CheckCircle,
  TrendingUp,
} from "lucide-react";

export default function Features() {
  const [activeTab, setActiveTab] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const tabs = [
    {
      id: 0,
      label: "Analytics",
      icon: BarChart,
      title: "Powerful Analytics Dashboard",
      description:
        "Track your sales, monitor customer behavior, and gain actionable insights with our comprehensive analytics platform. Make data-driven decisions that drive growth.",
      features: [
        "Real-time sales tracking",
        "Customer behavior insights",
        "Revenue forecasting",
        "Custom reports & dashboards",
      ],
      image:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop&auto=format&q=80",
    },
    {
      id: 1,
      label: "CRM",
      icon: Users,
      title: "Customer Relationship Management",
      description:
        "Build stronger relationships with your customers using our integrated CRM tools. Manage leads, track interactions, and nurture relationships at scale.",
      features: [
        "Lead management system",
        "Customer interaction tracking",
        "Automated follow-ups",
        "Contact segmentation",
      ],
      image:
        "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&h=400&fit=crop&auto=format&q=80",
    },
    {
      id: 2,
      label: "Automation",
      icon: Zap,
      title: "Smart Business Automation",
      description:
        "Streamline your workflows and save time with intelligent automation. From marketing campaigns to customer service, let AI handle the repetitive tasks.",
      features: [
        "Marketing automation",
        "Order processing",
        "Email sequences",
        "Task management",
      ],
      image:
        "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=600&h=400&fit=crop&auto=format&q=80",
    },
    {
      id: 3,
      label: "Security",
      icon: Shield,
      title: "Enterprise-Grade Security",
      description:
        "Protect your business and customer data with bank-level security. Enjoy peace of mind with our robust security infrastructure and compliance measures.",
      features: [
        "End-to-end encryption",
        "GDPR compliance",
        "Two-factor authentication",
        "Regular security audits",
      ],
      image:
        "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&h=400&fit=crop&auto=format&q=80",
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const currentTab = tabs[activeTab];

  return (
    <section
      id="features"
      ref={sectionRef}
      className="py-20 md:py-24 lg:py-32 px-6 bg-gray-50 dark:bg-[#0A0A0A] relative overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-32 bg-[#F5CDB3]/10 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-[#D0ECEE]/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Section Header */}
        <div
          className={`
          text-center mb-16 transition-all duration-1000 ease-out
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          <div className="inline-flex items-center gap-2 bg-[#F5CDB3]/20 border border-[#F5CDB3]/30 rounded-full px-4 py-2 mb-6">
            <Globe size={16} className="text-[#8B6914] dark:text-[#F5CDB3]" />
            <span
              className="text-[#8B6914] dark:text-[#F5CDB3] font-medium text-sm uppercase tracking-wide"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Features
            </span>
          </div>

          <h2
            className="text-[clamp(2.25rem,6vw,4rem)] leading-[1.1] font-bold text-black dark:text-white tracking-[-0.02em] mb-6"
            style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
          >
            Everything you need to
            <br />
            <span className="relative inline-block">
              <span className="relative z-10">succeed online</span>
              <div className="absolute bottom-2 left-0 w-full h-3 bg-gradient-to-r from-[#F5CDB3] to-[#E7B18E] opacity-60 -skew-x-6"></div>
            </span>
          </h2>

          <p
            className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Our comprehensive suite of tools helps you build, manage, and grow
            your business with confidence.
          </p>
        </div>

        {/* Tab Navigation */}
        <div
          className={`
          flex flex-wrap justify-center gap-2 mb-12 transition-all duration-1000 ease-out delay-200
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
        `}
        >
          {tabs.map((tab, index) => {
            const IconComponent = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(index)}
                className={`
                  flex items-center gap-3 px-6 py-3 rounded-full font-medium text-sm transition-all duration-300 hover:scale-105
                  ${
                    activeTab === index
                      ? "bg-[#F5CDB3] text-black shadow-lg"
                      : "bg-white dark:bg-[#1E1E1E] text-gray-600 dark:text-gray-300 hover:bg-[#F5CDB3]/10 dark:hover:bg-[#F5CDB3]/10"
                  }
                `}
                style={{ fontFamily: "Montserrat, sans-serif" }}
              >
                <IconComponent
                  size={18}
                  className={`transition-transform duration-200 ${activeTab === index ? "scale-110" : ""}`}
                />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div
          className={`
          grid lg:grid-cols-2 gap-12 items-center transition-all duration-1000 ease-out delay-400
          ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
        `}
        >
          {/* Content Side */}
          <div className="space-y-8">
            <div>
              <h3
                className="text-3xl md:text-4xl font-bold text-black dark:text-white mb-4 leading-tight"
                style={{ fontFamily: "Plus Jakarta Sans, sans-serif" }}
              >
                {currentTab.title}
              </h3>

              <p
                className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                {currentTab.description}
              </p>
            </div>

            {/* Feature List */}
            <div className="space-y-4">
              {currentTab.features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3 group">
                  <div className="w-6 h-6 rounded-full bg-[#F5CDB3]/20 flex items-center justify-center group-hover:bg-[#F5CDB3] transition-colors duration-200">
                    <CheckCircle
                      size={14}
                      className="text-[#8B6914] group-hover:text-black transition-colors duration-200"
                    />
                  </div>
                  <span
                    className="text-gray-700 dark:text-gray-300 font-medium"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {feature}
                  </span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <div className="pt-4">
              <button className="group bg-black dark:bg-white text-white dark:text-black font-semibold px-8 py-4 rounded-full hover:bg-[#F5CDB3] hover:text-black dark:hover:bg-[#F5CDB3] dark:hover:text-black transition-all duration-300 hover:scale-105 flex items-center gap-3">
                <span>Learn More</span>
                <TrendingUp
                  size={18}
                  className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-200"
                />
              </button>
            </div>
          </div>

          {/* Image Side */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl shadow-2xl bg-white dark:bg-[#1E1E1E] group">
              {/* Image Container */}
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={currentTab.image}
                  alt={currentTab.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>

              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>

              {/* Floating Metrics */}
              <div className="absolute top-4 right-4 bg-white dark:bg-[#1E1E1E] rounded-xl p-4 shadow-lg backdrop-blur-sm border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-gray-600 dark:text-gray-400 font-medium">
                    Live Data
                  </span>
                </div>
                <div className="text-lg font-bold text-black dark:text-white">
                  +127%
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  Growth
                </div>
              </div>

              {/* Bottom Stats */}
              <div className="absolute bottom-4 left-4 right-4 flex justify-between">
                <div className="bg-white/90 dark:bg-[#1E1E1E]/90 rounded-lg p-3 backdrop-blur-sm">
                  <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">
                    Revenue
                  </div>
                  <div className="text-lg font-bold text-black dark:text-white">
                    $47,832
                  </div>
                </div>
                <div className="bg-white/90 dark:bg-[#1E1E1E]/90 rounded-lg p-3 backdrop-blur-sm">
                  <div className="text-xs text-gray-600 dark:text-gray-400 mb-1">
                    Customers
                  </div>
                  <div className="text-lg font-bold text-black dark:text-white">
                    1,249
                  </div>
                </div>
              </div>
            </div>

            {/* Decorative Elements */}
            <div
              className="absolute -top-4 -left-4 w-8 h-8 bg-[#F5CDB3] rounded-full opacity-60 animate-bounce"
              style={{ animationDelay: "0s" }}
            ></div>
            <div
              className="absolute -bottom-4 -right-4 w-6 h-6 bg-[#E7B18E] rounded-full opacity-80 animate-bounce"
              style={{ animationDelay: "1s" }}
            ></div>
          </div>
        </div>
      </div>
    </section>
  );
}
